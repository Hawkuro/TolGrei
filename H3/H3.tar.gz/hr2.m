%%hr2
%fall sem keyrir pendul og byr til hreyfimynd med miklu utslagi
pendull('pendulODE',5,25,1,0,1,0,6)