pendull('roluODEmin',10, 25, 1,0,1,0,10)
pendull('roluODEmax',10, 25, 1,0,1,0,10)