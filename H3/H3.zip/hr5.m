%Forritsbutur sem byr til myndbandid af Lorentz attractor kerfi
%Gaeti thurft ad minnka resid, en thetta gefur allavegana frekar smooth feril svona
lorenzAnim(30,32,2^11,[[10;28;8/3],[10;65;12],[10;14;8/3],[10;0.5;8/3],[10;99.96;8/3]], [[5,5,5];[5,5,5];[5,5,5];[5,5,5];[5,5,5]], ['or'; 'og'; 'ob';'oy';'ow'], ['r';'g';'b';'y';'w']);
