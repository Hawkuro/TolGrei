function y = RHS (t,x)
y = (-3 * t * x^2 + 1/(1+t^3));